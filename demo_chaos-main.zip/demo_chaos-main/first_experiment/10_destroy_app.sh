##############################
# Destroying What We Created #
##############################

kubectl delete namespace chaosdemo
