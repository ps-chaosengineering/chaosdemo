pip3 install -U chaostoolkit-kubernetes

chaos discover chaostoolkit-kubernetes

cat discovery.json
